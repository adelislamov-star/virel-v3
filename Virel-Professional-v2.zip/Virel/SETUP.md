# 🚀 БЫСТРАЯ УСТАНОВКА VIREL

Пошаговая инструкция для запуска проекта за 15 минут.

---

## ✅ ШАГ 1: Проверка требований

Убедитесь что установлено:

```bash
# Проверьте Node.js (должно быть >= 18)
node --version

# Проверьте npm
npm --version

# Проверьте Git
git --version
```

❌ **Если что-то не установлено:**
- Node.js: https://nodejs.org/ (скачайте LTS версию)
- Git: https://git-scm.com/

---

## ✅ ШАГ 2: Установка PostgreSQL

### Вариант A: Локальная установка

**Windows:**
1. Скачайте: https://www.postgresql.org/download/windows/
2. Установите с настройками по умолчанию
3. Запомните пароль для пользователя `postgres`

**Mac:**
```bash
brew install postgresql@15
brew services start postgresql@15
```

### Вариант B: Облачная база (проще)

Используйте **Neon** (бесплатно):
1. Зайдите на https://neon.tech/
2. Создайте аккаунт
3. Создайте проект
4. Скопируйте `DATABASE_URL` (будет выглядеть как `postgresql://...`)

---

## ✅ ШАГ 3: Установка зависимостей

```bash
# Откройте PowerShell или CMD
cd C:\Virel

# Установите все пакеты (займёт 2-3 минуты)
npm install
```

---

## ✅ ШАГ 4: Настройка .env

1. Переименуйте `.env.example` в `.env`
2. Откройте `.env` в блокноте
3. Заполните переменные:

```env
# ===== БАЗА ДАННЫХ =====
# Локальная PostgreSQL:
DATABASE_URL="postgresql://postgres:ваш_пароль@localhost:5432/virel"

# ИЛИ облачная (Neon):
DATABASE_URL="postgresql://username:password@ep-xxx.us-east-2.aws.neon.tech/virel"

# ===== БЕЗОПАСНОСТЬ =====
# Сгенерируйте случайную строку (можно любую):
JWT_SECRET="super-secret-key-change-me-123456789"
NEXTAUTH_SECRET="another-secret-key-987654321"

# ===== TELEGRAM БОТЫ =====
# Токены ваших ботов (из @BotFather):
DIVA_RECEPTION_BOT_TOKEN="123456:ABC-DEF1234ghIkl-zyx57W2v1u123ew11"
KESHA_ZEROGAP_BOT_TOKEN="654321:XYZ-ABC9876ghIkl-abc12W3v4u567ew22"

# Chat ID для уведомлений (получить через @userinfobot):
TELEGRAM_CHAT_ID_RECEPTION="-1001234567890"
TELEGRAM_CHAT_ID_TOMMY="-1009876543210"

# ===== APPSHEET =====
# API ключ из AppSheet:
APPSHEET_API_KEY="V2-xxxxx-xxxxx-xxxxx"
APPSHEET_APP_ID="xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"

# ===== САЙТ =====
NEXT_PUBLIC_SITE_URL="http://localhost:3000"

# ===== АДМИН (для первого входа) =====
ADMIN_EMAIL="admin@virel.com"
ADMIN_PASSWORD="changeme123"
```

---

## ✅ ШАГ 5: Инициализация базы данных

```bash
# Сгенерировать Prisma client
npm run db:generate

# Создать таблицы в базе
npm run db:push
```

✅ **Ожидаемый результат:**
```
✔ Generated Prisma Client
✔ The database is now in sync with your Prisma schema
```

---

## ✅ ШАГ 6: Запуск проекта

```bash
# Запустить dev сервер
npm run dev
```

✅ **Ожидаемый результат:**
```
  ▲ Next.js 14.2.0
  - Local:        http://localhost:3000
  - ready started server on 0.0.0.0:3000
```

### Откройте браузер:
http://localhost:3000

🎉 **Готово! Сайт должен работать.**

---

## 🔧 ШАГ 7: Добавление тестовых данных (опционально)

### Открыть Prisma Studio:
```bash
npm run db:studio
```

Откроется http://localhost:5555

### Создайте тестовую модель:

1. Нажмите **Model** → **Add record**
2. Заполните:
   ```
   slug: sophia-mayfair
   name: Sophia
   age: 24
   nationality: British
   location: ["Mayfair", "Kensington"]
   height: 170
   weight: 55
   hairColor: Blonde
   eyeColor: Blue
   breastSize: C
   description: Elegant and sophisticated companion...
   languages: ["English", "French"]
   status: ACTIVE
   verified: true
   featured: true
   ```
3. Нажмите **Save**

Теперь модель появится на сайте!

---

## 📱 ШАГ 8: Проверка Telegram интеграции

### Тестовое бронирование:

1. Откройте http://localhost:3000/catalog/sophia-mayfair
2. Нажмите "Book Now"
3. Заполните форму и отправьте

**Ожидаемый результат:**
- Сообщение придёт в Telegram reception chat
- Через 30 минут - напоминание
- Через 45 минут - эскалация Tommy

---

## 🚨 ЧАСТЫЕ ПРОБЛЕМЫ

### ❌ "Cannot connect to database"

**Решение:**
```bash
# Проверьте что PostgreSQL запущен
# Windows: Services → PostgreSQL
# Mac: brew services list

# Проверьте DATABASE_URL в .env
# Попробуйте подключиться вручную:
psql -U postgres -h localhost
```

### ❌ "Module not found"

**Решение:**
```bash
rm -rf node_modules package-lock.json
npm install
```

### ❌ "Port 3000 already in use"

**Решение:**
```bash
# Убейте процесс на порту 3000
# Windows:
netstat -ano | findstr :3000
taskkill /PID <PID> /F

# Mac/Linux:
lsof -ti:3000 | xargs kill -9

# ИЛИ используйте другой порт:
PORT=3001 npm run dev
```

### ❌ Telegram боты не отправляют сообщения

**Чеклист:**
- [ ] Токены правильные (проверьте @BotFather)
- [ ] Chat ID правильные (проверьте @userinfobot)
- [ ] Бот добавлен в чат
- [ ] Бот имеет права администратора в групповом чате

---

## 📊 СЛЕДУЮЩИЕ ШАГИ

### 1. Добавить больше моделей
```bash
npm run db:studio
# Model → Add record × 10-15 моделей
```

### 2. Настроить изображения
- Поместите фото в `public/images/models/`
- Используйте WebP формат (оптимизация)
- Размер: 800x1200px минимум

### 3. Настроить geo-страницы
- Создайте файлы в `src/app/areas/[district]/page.tsx`
- Используйте шаблон из ТЗ

### 4. Деплой на Railway
```bash
# 1. Создайте Git репозиторий
git init
git add .
git commit -m "Initial commit"

# 2. Загрузите на GitHub
# 3. Подключите к Railway
# 4. Добавьте переменные окружения
```

---

## 🎯 ЧЕКЛИСТ ГОТОВНОСТИ К PRODUCTION

- [ ] Все .env переменные заполнены
- [ ] База данных работает
- [ ] Telegram боты отвечают
- [ ] Добавлено минимум 10 моделей
- [ ] Изображения оптимизированы (WebP)
- [ ] SSL сертификат установлен
- [ ] Google Analytics подключен
- [ ] Sitemap сгенерирован
- [ ] Robots.txt настроен
- [ ] 301 редиректы настроены (если была старая версия)

---

## 💬 НУЖНА ПОМОЩЬ?

1. Проверьте **README.md** - подробная документация
2. Откройте **GitHub Issues**
3. Напишите: dev@virel.com

---

**Удачи с запуском! 🚀**
