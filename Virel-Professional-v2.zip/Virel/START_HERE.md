# 🚀 START HERE - Virel MVP

**Всё готово! Просто следуйте этим 5 шагам.**

---

## ⚡ Быстрый запуск (5 шагов)

### 1️⃣ Скопируйте проект на C:\Virel

Вы уже скачали папку `Virel` → Просто переместите её в `C:\Virel`

### 2️⃣ Откройте PowerShell в папке проекта

```powershell
cd C:\Virel
```

### 3️⃣ Установите зависимости

```powershell
npm install
```
⏱️ Займёт 2-3 минуты

### 4️⃣ Настройте .env

```powershell
# Переименуйте файл
copy .env.example .env

# Откройте в блокноте
notepad .env
```

**Заполните обязательные поля:**

```env
# База данных (самый простой вариант - используйте Neon.tech бесплатно)
DATABASE_URL="postgresql://..."

# Секреты (любые случайные строки)
JWT_SECRET="ваш-секретный-ключ-123456"

# Telegram боты (ваши токены)
DIVA_RECEPTION_BOT_TOKEN="123456:ABC-DEF..."
KESHA_ZEROGAP_BOT_TOKEN="654321:XYZ-ABC..."
TELEGRAM_CHAT_ID_RECEPTION="-1001234567890"
TELEGRAM_CHAT_ID_TOMMY="-1009876543210"

# AppSheet
APPSHEET_API_KEY="V2-xxxxx..."
APPSHEET_APP_ID="xxxxxxxx-xxxx..."
```

### 5️⃣ Запустите проект

```powershell
# Инициализировать базу
npm run db:generate
npm run db:push

# Добавить тестовые данные (3 модели + пользователи)
npm run db:seed

# Запустить сайт
npm run dev
```

✅ **Готово!** Откройте http://localhost:3000

---

## 🎯 Что дальше?

### Первые шаги:

1. **Зайдите в админку**: http://localhost:3000/admin
   - Email: `admin@virel.com`
   - Password: `changeme123`

2. **Откройте Prisma Studio** (управление базой):
   ```powershell
   npm run db:studio
   ```
   Откроется http://localhost:5555

3. **Добавьте свои модели**:
   - Через Prisma Studio → Model → Add record
   - ИЛИ через админку (когда доделаете CRUD)

---

## 📚 Документация

- **SETUP.md** → Подробная установка (если что-то не работает)
- **README.md** → Полная документация проекта
- **PROJECT_OVERVIEW.md** → Обзор всех файлов

---

## ✅ Готовые функции

### Frontend (100%)
- ✅ Главная страница
- ✅ Каталог с фильтрами
- ✅ Профиль модели с галереей
- ✅ Форма бронирования
- ✅ FAQ с Schema
- ✅ Mobile адаптив

### Backend (90%)
- ✅ API бронирований (POST /api/bookings)
- ✅ API моделей (GET /api/models)
- ✅ Telegram интеграция (DivaBot + KeshaBot)
- ✅ Database (PostgreSQL + Prisma)
- ⚠️ TODO: Auth middleware для админки

### Админка (60%)
- ✅ Dashboard со статистикой
- ⚠️ TODO: CRUD для моделей
- ⚠️ TODO: Управление бронированиями
- ⚠️ TODO: Логин/Authentication

---

## 🐛 Проблемы?

### "Cannot connect to database"
→ Проверьте DATABASE_URL в .env
→ Используйте Neon.tech для облачной БД (бесплатно)

### "Module not found"
```powershell
rm -rf node_modules
npm install
```

### "Port 3000 already in use"
```powershell
# Используйте другой порт
$env:PORT=3001; npm run dev
```

---

## 🎨 Тестовые данные

После `npm run db:seed` у вас будет:

**👤 Пользователи:**
- Admin: `admin@virel.com` / `changeme123`
- Tommy: `tommy@virel.com` / `tommy123`
- Lukas: `lukas@virel.com` / `lukas123`
- Sasha: `sasha@virel.com` / `sasha123`
- Adam: `adam@virel.com` / `adam123`
- Donald: `donald@virel.com` / `donald123`

**👩 Модели:**
- Sophia (Mayfair) - /catalog/sophia-mayfair
- Isabella (Kensington) - /catalog/isabella-kensington
- Olivia (Chelsea) - /catalog/olivia-chelsea

---

## 🚢 Деплой на Railway

Когда всё работает локально:

```powershell
# 1. Создайте Git репозиторий
git init
git add .
git commit -m "Initial commit"

# 2. Загрузите на GitHub
# Создайте репозиторий на github.com
git remote add origin https://github.com/ваш-username/virel.git
git push -u origin main

# 3. Зайдите на Railway.app
# - Подключите GitHub репозиторий
# - Railway автоматически создаст PostgreSQL
# - Добавьте все переменные из .env
# - Deploy!
```

---

## 💡 Полезные команды

```powershell
npm run dev          # Запуск dev сервера
npm run build        # Production build
npm run db:studio    # Открыть Prisma Studio
npm run db:seed      # Добавить тестовые данные
npm run lint         # Проверка кода
```

---

## 🎯 TODO для полного MVP

**Высокий приоритет (1-2 недели):**
- [ ] Authentication для админки (JWT)
- [ ] CRUD для моделей в админке
- [ ] Управление бронированиями в админке
- [ ] Geo-страницы (12 районов)
- [ ] Загрузка реальных изображений

**Средний приоритет:**
- [ ] Email уведомления
- [ ] Платежная система (Stripe)
- [ ] Расширенная аналитика

---

## 📞 Нужна помощь?

1. Читайте **SETUP.md** - там всё подробно
2. Смотрите **README.md** - полная документация
3. Проверьте **PROJECT_OVERVIEW.md** - обзор файлов

---

**🎉 Всё готово! Начинайте работать!**

_Проект создан специально для Virel_
_Версия: 1.0.0 MVP_
